/*
 *Copyright (c) 2009-2018, Ioannis Vasilopoulos
 *All rights reserved.
 *
 *Redistribution and use in source and binary forms, with or without
 *modification, are permitted provided that the following conditions are met:
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *    * Neither the name of Koios nor the
 *      names of its contributors may be used to endorse or promote products
 *      derived from this software without specific prior written permission.
 *
 *THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 *ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
 *DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */


package org.coeus.wizards.If;
import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JPanel;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionEvent;

import javax.swing.event.ListSelectionListener;
import javax.swing.plaf.ColorUIResource;
import net.java.balloontip.BalloonTip;
import net.java.balloontip.BalloonTip.AttachLocation;
import net.java.balloontip.BalloonTip.Orientation;
import net.java.balloontip.styles.BalloonTipStyle;
import net.java.balloontip.styles.RoundedBalloonStyle;
import org.coeus.wizards.WizardsDefinitions;
import org.coeus.wizards._HelpFuntions.addCommandConditionPanel;

import org.openide.DialogDisplayer;
import org.openide.NotifyDescriptor;

public final class IfVisualPanel1 extends JPanel {
    private String objScope;
   


    private LinkedList <String> dispStatement= new LinkedList<String>();
    private LinkedList <String> objStatement= new LinkedList<String>();
    private LinkedList <String> dispStatementCategory= new LinkedList<String>();
    private LinkedList <Integer> oldPosition= new LinkedList<Integer>();
    private LinkedList <Integer> currentPosition= new LinkedList<Integer>();

    private static final int stringListSize=35;
    private int selection=-1;
    private DefaultListModel listModel = null;
   

     private String commandName=null;
    /** Creates new form ReadVisualPanel1 */
    public IfVisualPanel1(String iObjScope,String icommandName) {
        initComponents();


     //customize tool tip apperance
        UIManager.put("ToolTip.background", new ColorUIResource(220, 220, 220)); // The color is #fff7c8.
        Border border = BorderFactory.createLineBorder(new Color(76,79,83)); // The color is #4c4f53.
        UIManager.put("ToolTip.border", border);
        ToolTipManager.sharedInstance().setInitialDelay(0);
        ToolTipManager.sharedInstance().setDismissDelay(20000);// 20 seconds
        //end customize tool tip apperance

 addElseIf.setToolTipText("<html><font color=\"#003333\""+"size=\"4\" face=\"Tahoma\">"+
           "Πατήστε το κουμπί \"" + "<b>Προσθήκη ΑΛΛΙΩΣ ΑΝ</b>"+ "\" για να<br>εισάγετε ενα ΤΜΗΜΑ ΑΛΛΙΩΣ ΑΝ στην εντολή ΑΝ..ΑΛΛΙΩΣ"+"</font></html>");

 addElse.setToolTipText("<html><font color=\"#003333\""+"size=\"4\" face=\"Tahoma\">"+
         "Πατήστε το κουμπί \"" + "<b>Προσθήκη ΑΛΛΙΩΣ</b>"+ "\" για να<br>εισάγετε ενα ΤΜΗΜΑ ΑΛΛΙΩΣ στην εντολή ΑΝ..ΑΛΛΙΩΣ"+"</font></html>");




        this.objScope=iObjScope;
        this.commandName=icommandName;
        setEditDeleteButtonsEnabled(false);
        
     

        listModel = new DefaultListModel();
        jList1.setModel(listModel);


        jList1.addListSelectionListener(new ListSelectionListener() {

            public void valueChanged(ListSelectionEvent e) {
                int sel;
                sel=jList1.getSelectedIndex();
                if (sel>-1)
                {
                  selection=sel;
                  checkButtons();
                }
            }
        });

    jList1.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) {
                checkButtons(); }
            public void focusLost(FocusEvent e) {
            }
        });

            jList1.addMouseListener(new MouseListener () {

            public void mouseClicked(MouseEvent e) {
               if (selection>-1)
                  if(e.getClickCount() == 2)
                       editElement();
            }

            public void mousePressed(MouseEvent e) {

            }

            public void mouseReleased(MouseEvent e) {

            }

            public void mouseEntered(MouseEvent e) {

            }

            public void mouseExited(MouseEvent e) {

            }

        });
    }


    public void getIfStatement()
    {
     addIfStatement();
    }


    @Override
    public String getName() {
        return "Καθορισμός Συνθηκών Εντολής ΑΝ";
    }

     private void setEditDeleteButtonsEnabled(boolean tf)
    {
      EditBut.setEnabled(tf);
      DeleteSelectedBut.setEnabled(tf);
      DeleteAllBut.setEnabled(tf);
    }

    private void setDeleteButtonsEnabled(boolean tf)
    {
      DeleteSelectedBut.setEnabled(tf);
      DeleteAllBut.setEnabled(tf);
    }
  


    public void setAddButtonsEnabled(boolean tf)
    {
    this.addElse.setEnabled(tf);
    this.addElseIf.setEnabled(tf);
    }


  ///GETTERS


    public LinkedList<String> getDispStatements()
    {return this.dispStatement;}

     public LinkedList<String> getObjStatements()
    {return this.objStatement;}

     public LinkedList<String> getDispStatementsCategories()
    {return this.dispStatementCategory;}

    public LinkedList<Integer> getOldPositions()
    {return this.oldPosition;}

    public LinkedList<Integer> getCurrentPositions()
    {return this.currentPosition;}

     /////SETTERS


    public void setDispStatements(LinkedList<String> iDispStatement)
    {this.dispStatement=iDispStatement;}

    public void setObjStatements(LinkedList<String> iObjStatement)
    {this.objStatement=iObjStatement;}

     public void setDispStatementCategories(LinkedList<String> iDispStatementCategories)
    {this.dispStatementCategory=iDispStatementCategories;}

    public void setOldPositions(LinkedList<Integer> iOldPositions)
    {this.oldPosition=iOldPositions;}
    
    public void setCurrentPositions(LinkedList<Integer> iCurrentPositions)
    {this.currentPosition=iCurrentPositions;}

     public String strings2ListModelItem(String category,String type)
     { String result="",ncategory,ntype;

       if (category.length()>stringListSize)
           ncategory=category.substring(0,stringListSize);
       else
         ncategory = padWithSpaceChars(category);

       ntype=type;

     result=ncategory+ntype;
     return result;
     }

    private String padWithSpaceChars (String inString)
    {String temp="",outString="";
    int difference = stringListSize- inString.length();
    for (int i=0;i<difference;i++)
        temp=temp+" ";
    outString=inString+temp;
    return outString;
    }

private void addIfStatement()
{addCondition(WizardsDefinitions.IF_STATEMENT,"ΑΝ",NotifyDescriptor.DEFAULT_OPTION);
}

private void updateIfStatement()
{updateCondition(WizardsDefinitions.IF_STATEMENT,"ΑΝ");}

private void addElseIfStatement()
{addCondition(WizardsDefinitions.ELSE_IF_STATEMENT,"ΑΛΛΙΩΣ ΑΝ",NotifyDescriptor.OK_CANCEL_OPTION);
}

private void updateElseIfStatement()
{updateCondition(WizardsDefinitions.ELSE_IF_STATEMENT,"ΑΛΛΙΩΣ ΑΝ");
}

private void addElseStatement()
{
 dispStatement.add("");
 objStatement.add("");
 dispStatementCategory.add(WizardsDefinitions.ELSE_STATEMENT);

 listModel.addElement(strings2ListModelItem(WizardsDefinitions.ELSE_STATEMENT,""));

 setAddButtonsEnabled(false);
}

private void updateElseStatement()
{}

private void editElement()
{
 if (selection>-1)
 {
  if (dispStatementCategory.get(selection).equalsIgnoreCase(WizardsDefinitions.IF_STATEMENT))
          updateIfStatement();
  else if (dispStatementCategory.get(selection).equalsIgnoreCase(WizardsDefinitions.ELSE_IF_STATEMENT))
          updateElseIfStatement();
  else if (dispStatementCategory.get(selection).equalsIgnoreCase(WizardsDefinitions.ELSE))
          updateElseStatement();
  jList1.setSelectedIndex(selection);
 }
}



  
 public void addCondition(String statement,String textLabel, int buttons)
    {
     addCommandConditionPanel aCP = new addCommandConditionPanel(this.objScope,null,this.commandName);
     aCP.getTextFiledLabel().setText(textLabel);


     aCP.getHeaders()[0].setText("Δημιουργία Λογικής Συνθήκης για το");
     aCP.getHeaders()[1].setText(statement);
     aCP.getHeaders()[2].setVisible(false);
     aCP.getHeaders()[3].setVisible(false);
     aCP.showParenthesisLabels(true);


      NotifyDescriptor d =new NotifyDescriptor.Confirmation(aCP,
      "Δημιουργία Λογικής Συνθήκης για το "+statement,
      buttons,NotifyDescriptor.PLAIN_MESSAGE);

     Object answer= DialogDisplayer.getDefault().notify(d);

    if (buttons ==NotifyDescriptor.DEFAULT_OPTION )
     {
      while (answer==NotifyDescriptor.CLOSED_OPTION)
        answer= DialogDisplayer.getDefault().notify(d);
     }


     if (answer==NotifyDescriptor.OK_OPTION)
      {
        if (aCP.checkValidCondition(NotifyDescriptor.DEFAULT_OPTION))
         {
         if (newCondition(aCP.getDisplayCondition(),statement))
         {
             dispStatement.add(aCP.getDisplayCondition());
             objStatement.add(aCP.getObjectCondition());
             dispStatementCategory.add(statement);


            listModel.addElement(strings2ListModelItem(statement,aCP.getDisplayCondition()));
         }
        }
      }
    }




    public void updateCondition(String statement,String textLabel)
    {
     addCommandConditionPanel aCP = new addCommandConditionPanel(this.objScope,dispStatement.get(selection),this.commandName);
     aCP.getTextFiledLabel().setText(textLabel);


     aCP.getHeaders()[0].setText("Μεταβολή Λογικής Συνθήκης για το");
     aCP.getHeaders()[1].setText(statement);
     aCP.getHeaders()[2].setVisible(false);
     aCP.getHeaders()[3].setVisible(false);
     aCP.showParenthesisLabels(true);



      NotifyDescriptor d =new NotifyDescriptor.Confirmation(aCP,
      "Μεταβολή Λογικής Συνθήκης για το "+statement,
      NotifyDescriptor.OK_CANCEL_OPTION,NotifyDescriptor.PLAIN_MESSAGE);

      if ( DialogDisplayer.getDefault().notify(d)==NotifyDescriptor.OK_OPTION)
      {
        if (aCP.checkValidCondition(NotifyDescriptor.OK_CANCEL_OPTION))
         {
          if (newCondition(aCP.getDisplayCondition(),statement))
          {
           dispStatement.remove(selection);
           objStatement.remove(selection);
           dispStatementCategory.remove(selection);

           dispStatement.add(selection,aCP.getDisplayCondition());
           objStatement.add(selection,aCP.getObjectCondition());
           dispStatementCategory.add(selection,statement);

          listModel.remove(selection);
          listModel.insertElementAt(strings2ListModelItem(statement,aCP.getDisplayCondition()),selection);
          }
        }
      }
    }


private boolean newCondition(String condition,String statement)
{
 boolean conditionFound=false;

 for (int i=0;i<this.dispStatement.size();i++)
     if(this.dispStatement.get(i).equalsIgnoreCase(condition))
         conditionFound=true;
 if (conditionFound)
 {
  NotifyDescriptor d =new NotifyDescriptor.Confirmation("Η ΛΟΓΙΚΗ ΣΥΝΘΗΚΗ που είσαγατε έχει εισαχθεί σε άλλο" +
  " ΤΜΗΜΑ ΑΝ ή ΑΛΛΙΩΣ ΑΝ\nΕίστε σίγουροι ότι θέλετε να κρατήσετε τη ΛΟΓΙΚΗ ΣΥΝΘΗΚΗ ως έχει για το συγκεκριμένο "+statement+" ;",
  "Δημιουργία Λογικής Συνθήκης για το ",
   NotifyDescriptor.YES_NO_OPTION,NotifyDescriptor.QUESTION_MESSAGE);

   if ( DialogDisplayer.getDefault().notify(d)==NotifyDescriptor.YES_OPTION)
      return true;
   else
     return false;
 }
 else
     return true;

}

     private void checkButtons()
    {

       if (selection>-1)
       {
         if (this.dispStatementCategory.get(selection).equalsIgnoreCase(WizardsDefinitions.IF_STATEMENT))
         {
         this.EditBut.setEnabled(true);
         setDeleteButtonsEnabled(false);
         }
         else if (this.dispStatementCategory.get(selection).equalsIgnoreCase(WizardsDefinitions.ELSE_IF_STATEMENT))
         setEditDeleteButtonsEnabled(true);
         else if (this.dispStatementCategory.get(selection).equalsIgnoreCase(WizardsDefinitions.ELSE_STATEMENT))
         {
         setEditDeleteButtonsEnabled(true);
         this.EditBut.setEnabled(false);
         }
       }
    }


private void clearAll()
{ String s1,s2,s3;
     NotifyDescriptor d =new NotifyDescriptor.Confirmation(
                "Πρόκειται να διαγράψετε όλα τα στοιχεία τα τμήματα ΑΛΛΙΩΣ ΑΝ και ΑΛΛΙΩΣ!\n" +
                "Είστε σίγουροι οτι θέλετε να συνεχίσετε;",
                "Επιβεβαίωση Διαγραφής ",
     NotifyDescriptor.YES_NO_OPTION,NotifyDescriptor.WARNING_MESSAGE);

         if (DialogDisplayer.getDefault().notify(d) == NotifyDescriptor.YES_OPTION) {

           s1= dispStatement.get(0);
           s2=objStatement.get(0);
           s3=dispStatementCategory.get(0);

           dispStatement.clear();
           objStatement.clear();
           dispStatementCategory.clear();

           listModel.clear();


           dispStatement.add(s1);
           objStatement.add(s2);
           dispStatementCategory.add(s3);

           listModel.addElement(strings2ListModelItem(s3,s1));
        

           setEditDeleteButtonsEnabled(false);
     
           
         setAddButtonsEnabled(true);
           selection=-1;
     }
}


public void clearOne()
{
   if (selection>-1)
         {
           String temp=this.dispStatementCategory.get(selection);
           dispStatement.remove(selection);
           objStatement.remove(selection);
           dispStatementCategory.remove(selection);    

           listModel.remove(selection);

          if (selection==0 && !listModel.isEmpty())
          {}
          else if (selection<=listModel.size() )
             selection=selection-1;
        

          if (temp.equalsIgnoreCase(WizardsDefinitions.ELSE_STATEMENT))
          setAddButtonsEnabled(true);

         jList1.setSelectedIndex(selection);
      }

}

    public DefaultListModel getListModel()
    {return this.listModel;}



      private void createDirectionsPopupWindow()
   {


       String balloonText="<html><div align=\"justify\"><font color=\"#000000\"size=\"4\" face=\"Tahoma\">" +
                      "Η εντολή ΑΝ..ΑΛΛΙΩΣ χρησιμοποιείται για να εκτελεί διαφορετικά τμήματα εντολών<br>" +
                      "ανάλογα με το αν ισχύει μια συνθήκη ή όχι.Αποτελείται από ακριβώς ένα τμήμα ΑΝ,<br>" +
                      "κανένα ή περισσότερα ΤΜΗΜΑΤΑ ΑΛΛΙΩΣ ΑΝ και κανένα ή ένα ΤΜΗΜΑ ΑΛΛΙΩΣ.Τα ΤΜΗΜΑΤΑ<br>" +
                      "ΑΛΛΙΩΣ ΑΝ δέχονται την δικής τους συνθήκη ενώ το ΤΜΗΜΑ ΑΛΛΙΩΣ δεν δέχεται συνθήκη.<br>" +
                      "Η συνθήκη στο ΤΜΗΜΑ ΑΝ δημιουργείται κατά την εισαγωγή μιας εντολή ΑΝ..ΑΛΛΙΩΣ στο<br>" +
                      "πρόγραμμα. Τα ΤΜΗΜΑΤΑ ΑΛΛΙΩΣ ΑΝ μπορούν να προστεθούν στην εντολή ΑΝ..ΑΛΛΙΩΣ<br>" +
                      "πατώντας το κουμπί <b>«Προσθήκη ΑΛΛΙΩΣ ΑΝ»</b> ενώ το ΤΜΗΜΑ ΑΛΛΙΩΣ πατώντας το<br>" +
                      "κουμπί <b>«Προσθήκη ΑΛΛΙΩΣ»</b>.Μέτα την προσθήκη ενός ΤΜΗΜΑΤΟΣ ΑΛΛΙΩΣ δεν μπορούν<br>" +
                      "να εισαχθούν άλλα ΤΜΗΜΑ ΑΛΛΙΩΣ ΑΝ ή ΑΛΛΙΩΣ.Αν θέλετε να προσθέσετε και άλλα ΤΜΗΜΑΤΑ <br>" +
                      "ΑΛΛΙΩΣ ΑΝ θα πρέπει πρώτα να διαγράψετε το ΤΜΗΜΑ ΑΛΛΙΩΣ.Μπορείτε να επεξεργαστείτε,<br>" +
                      "να διαγράψετε ένα ή όλα τα ΤΜΗΜΑΤΑ ΑΝ,ΑΛΛΙΩΣ ΑΝ και ΑΛΛΙΩΣ με τα κουμπιά<br>" +
                      "<b>«Επεξεργασία Επιλεγμένου Στοιχείου»</b>,<b>«Διαγραφή Επιλεγμένου Στοιχείου»</b>, και<br>" +
                      "<b>«Διαγραφή Όλων των Στοιχείων»</b> αντίστοιχα. Το ΤΜΗΜΑ ΑΝ δεν μπορεί να διαγραφεί,<br>" +
                      "ενώ το τμήμα ΑΛΛΙΩΣ δεν μπορεί να επεξεργαστεί αφού δεν περιέχει συνθήκη.</font></div></html>";

       BalloonTipStyle edgedLook = new RoundedBalloonStyle(10,10,Color.WHITE, Color.BLUE);

     new BalloonTip(this.directionsButton,balloonText,edgedLook,Orientation.RIGHT_ABOVE,AttachLocation.SOUTHWEST,40,20,true  );

   }


    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        addElseIf = new javax.swing.JButton();
        addElse = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        EditBut = new javax.swing.JButton();
        DeleteSelectedBut = new javax.swing.JButton();
        DeleteAllBut = new javax.swing.JButton();
        directionsButton = new javax.swing.JButton();

        org.openide.awt.Mnemonics.setLocalizedText(addElseIf, org.openide.util.NbBundle.getMessage(IfVisualPanel1.class, "IfVisualPanel1.addElseIf.text")); // NOI18N
        addElseIf.setPreferredSize(new java.awt.Dimension(155, 25));
        addElseIf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addElseIfActionPerformed(evt);
            }
        });

        org.openide.awt.Mnemonics.setLocalizedText(addElse, org.openide.util.NbBundle.getMessage(IfVisualPanel1.class, "IfVisualPanel1.addElse.text")); // NOI18N
        addElse.setPreferredSize(new java.awt.Dimension(155, 25));
        addElse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addElseActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, org.openide.util.NbBundle.getMessage(IfVisualPanel1.class, "IfVisualPanel1.jPanel1.border.title"), javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(102, 102, 102))); // NOI18N

        jScrollPane1.setViewportView(jList1);

        org.openide.awt.Mnemonics.setLocalizedText(EditBut, org.openide.util.NbBundle.getMessage(IfVisualPanel1.class, "IfVisualPanel1.EditBut.text")); // NOI18N
        EditBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditButActionPerformed(evt);
            }
        });

        org.openide.awt.Mnemonics.setLocalizedText(DeleteSelectedBut, org.openide.util.NbBundle.getMessage(IfVisualPanel1.class, "IfVisualPanel1.DeleteSelectedBut.text")); // NOI18N
        DeleteSelectedBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteSelectedButActionPerformed(evt);
            }
        });

        org.openide.awt.Mnemonics.setLocalizedText(DeleteAllBut, org.openide.util.NbBundle.getMessage(IfVisualPanel1.class, "IfVisualPanel1.DeleteAllBut.text")); // NOI18N
        DeleteAllBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteAllButActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(EditBut)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DeleteSelectedBut)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DeleteAllBut))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 585, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EditBut)
                    .addComponent(DeleteSelectedBut)
                    .addComponent(DeleteAllBut)))
        );

        org.openide.awt.Mnemonics.setLocalizedText(directionsButton, org.openide.util.NbBundle.getMessage(IfVisualPanel1.class, "IfVisualPanel1.directionsButton.text")); // NOI18N
        directionsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                directionsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 602, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(addElseIf, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(addElse, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(directionsButton)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addElseIf, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addElse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(directionsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void addElseIfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addElseIfActionPerformed
        addElseIfStatement();
}//GEN-LAST:event_addElseIfActionPerformed

    private void addElseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addElseActionPerformed
        addElseStatement();
}//GEN-LAST:event_addElseActionPerformed

    private void EditButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditButActionPerformed
        editElement();
}//GEN-LAST:event_EditButActionPerformed

    private void DeleteSelectedButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteSelectedButActionPerformed
        clearOne();
}//GEN-LAST:event_DeleteSelectedButActionPerformed

    private void DeleteAllButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteAllButActionPerformed
        clearAll();
}//GEN-LAST:event_DeleteAllButActionPerformed

    private void directionsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_directionsButtonActionPerformed
       createDirectionsPopupWindow();
    }//GEN-LAST:event_directionsButtonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeleteAllBut;
    private javax.swing.JButton DeleteSelectedBut;
    private javax.swing.JButton EditBut;
    private javax.swing.JButton addElse;
    private javax.swing.JButton addElseIf;
    private javax.swing.JButton directionsButton;
    private javax.swing.JList jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}

