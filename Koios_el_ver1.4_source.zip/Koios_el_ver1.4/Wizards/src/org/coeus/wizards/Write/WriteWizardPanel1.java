/*
 *Copyright (c) 2009-2018, Ioannis Vasilopoulos
 *All rights reserved.
 *
 *Redistribution and use in source and binary forms, with or without
 *modification, are permitted provided that the following conditions are met:
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *    * Neither the name of Koios nor the
 *      names of its contributors may be used to endorse or promote products
 *      derived from this software without specific prior written permission.
 *
 *THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 *ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
 *DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

package org.coeus.wizards.Write;

import java.awt.Component;
import javax.swing.DefaultListModel;
import javax.swing.event.ChangeListener;
import org.coeus.wizards.Messages;
import org.coeus.wizards.WizardSettingsValues;
import org.openide.DialogDisplayer;
import org.openide.NotifyDescriptor;
import org.openide.WizardDescriptor;
import org.openide.WizardValidationException;
import org.openide.util.HelpCtx;

public class WriteWizardPanel1 implements WizardDescriptor.ValidatingPanel {

    /**
     * The visual component that displays this panel. If you need to access the
     * component from this class, just use getComponent().
     */
    private WriteVisualPanel1 component;
    private String objScope;
    private WizardDescriptor wizardDescriptor;

    // Get the visual component for the panel. In this template, the component
    // is kept separate. This can be more efficient: if the wizard is created
    // but never displayed, or not all panels are displayed, it is better to
    // create only those which really need to be visible.

    public WriteWizardPanel1(String iObjScope)
    {this.objScope=iObjScope;}

    public Component getComponent() {
        if (component == null) {
            component = new WriteVisualPanel1(this.objScope);
        }
        return component;
    }

    public HelpCtx getHelp() {
        // Show no Help button for this panel:
        return HelpCtx.DEFAULT_HELP;
    // If you have context help:
    // return new HelpCtx(SampleWizardPanel1.class);
    }

    public boolean isValid() {
        return true;
    }

    public final void addChangeListener(ChangeListener l) {
    }

    public final void removeChangeListener(ChangeListener l) {
    }
   
    // You can use a settings object to keep track of state. Normally the
    // settings object will be the WizardDescriptor, so you can use
    // WizardDescriptor.getProperty & putProperty to store information entered
    // by the user.
    public void readSettings(Object settings) {
           boolean update;

      wizardDescriptor = (WizardDescriptor) settings;
      wizardDescriptor.putProperty(WizardDescriptor.PROP_INFO_MESSAGE, Messages.INFO_PRO_PANEL2);

      update = (Boolean)wizardDescriptor.getProperty(WizardSettingsValues.UPDATE);
      if (update && !WriteWizardAction.getDispArguements().isEmpty())
      {
            DefaultListModel listModel=component.getListModel();

        for (int q=0;q<WriteWizardAction.getDispArguements().size();q++)

             listModel.addElement(component.strings2ListModelItem(WriteWizardAction.getDispArguements().get(q),
                     WriteWizardAction.getDispCategory().get(q),WriteWizardAction.getDispArguementsType().get(q)));

             component.setDispArguements(WriteWizardAction.getDispArguements());
             component.setDispArguementsType(WriteWizardAction.getDispArguementsType());
             component.setObjArguements(WriteWizardAction.getObjArguements());
             component.setObjArguementsType(WriteWizardAction.getObjArguementsType());
             component.setDispCategory(WriteWizardAction.getDispCategory());
      }

    }


    public void storeSettings(Object settings) {

        WriteWizardAction.setDispArguements(component.getDispArguements());
        WriteWizardAction.setObjArguements(component.getObjArguements());
        WriteWizardAction.setDispArguementsType(component.getDispArguementsType());
        WriteWizardAction.setObjArguementsType(component.getObjArguementsType());
        WriteWizardAction.setDispCategory(component.getDispCategory());

    }

    public void validate() throws WizardValidationException {
        DefaultListModel listModel = component.getListModel();

        if(listModel.isEmpty())
        {
         NotifyDescriptor d=  new NotifyDescriptor.Confirmation("Αν η εντολή ΓΡΑΨΕ δεν έχει ορίσματα τότε" +
                 " θα εκτυπώσει στην οθόνη μια κενή γραμμή!\nΕίστε σίγουροί οτι θέλετε να μείνει χωρίς ορίσματα;",
                 "Εντολή ΓΡΑΨΕ χωρίς ορίσματα",
                      NotifyDescriptor.YES_NO_OPTION,NotifyDescriptor.INFORMATION_MESSAGE);
            
            
            if (DialogDisplayer.getDefault().notify(d)==NotifyDescriptor.NO_OPTION)
                throw new WizardValidationException(null, null, null);
        }

    }
}

